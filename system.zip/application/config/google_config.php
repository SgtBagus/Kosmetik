<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']="359141067884-39jb1lisg9i9dfg56nihpac19s9avp6s.apps.googleusercontent.com";
$config['google_client_secret']="dfiGUZERNvBEd07DTsdIFZj4";
$config['google_redirect_url']=base_url().'login/loginGoogle';

