/**
* @api {get} http://gatoko1.com/sop/api/ Curl Configuration
* @apiVersion 1.1.0
* @apiParam {String} auth type-auth : basic
* @apiParam {String} username sm4rts0ft
* @apiParam {String} password ?zwMAxBnS9jj
* @apiParam {String} x-sm-key 35d3d08c3d7b7f445ceb8e726a87b26c

* @apiName GetConfiguration
* @apiGroup Configuration
*/

